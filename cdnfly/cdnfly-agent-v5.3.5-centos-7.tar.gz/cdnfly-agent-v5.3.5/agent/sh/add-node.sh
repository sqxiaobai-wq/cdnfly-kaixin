#!/bin/bash

eval `grep MASTER_IP /opt/cdnfly/agent/conf/config.py | sed 's/ //g'`
eval `grep ES_PWD /opt/cdnfly/agent/conf/config.py | sed 's/ //g'`
eval `grep MASTER_HOST /opt/cdnfly/agent/conf/config.py | sed 's/ //g'`

if [[ "$MASTER_HOST" == "" ]];then
	MASTER_HOST=$MASTER_IP
fi


echo "开始往主控发送请求注册节点..."
cmd="curl -v -X POST -H \"Host: $MASTER_HOST\"  http://$MASTER_IP:88/new-node -H \"es-pwd: $ES_PWD\" "
ret=`eval $cmd || true`
if [[ "$ret" =~ "pending_node" || "$ret" =~ "success" ]];then
    echo "注册成功，请登录后台，切换到待初始化菜单, 来初始化节点"

elif [[ "$ret" =~ "in node" ]];then
    node_id=`echo $ret | grep -Po "id:\d+" | sed 's/id://g'`
    sed -i "s/NODE_ID.*/NODE_ID = \"$node_id\"/" /opt/cdnfly/agent/conf/config.py
    supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart agent
    supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task        
    echo "该节点已存在于CDN后台，请登录后台禁用并启动此节点完成初始化"

else
    echo "注册失败，请手动执行如下命令来检查原因"
    echo $cmd
fi
