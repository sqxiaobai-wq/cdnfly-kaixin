#!/bin/bash

set -o errexit

download(){
  local url1=$1
  local url2=$2
  local filename=$3

  speed1=`curl -m 5 -L -s -w '%{speed_download}' "$url1" -o /dev/null || true`
  speed1=${speed1%%.*}
  speed2=`curl -m 5 -L -s -w '%{speed_download}' "$url2" -o /dev/null || true`
  speed2=${speed2%%.*}
  echo "speed1:"$speed1
  echo "speed2:"$speed2
  url="$url1\n$url2"
  if [[ $speed2 -gt $speed1 ]]; then
    url="$url2\n$url1"
  fi
  echo -e $url | while read l;do
    echo "using url:"$l
    wget --dns-timeout=5 --connect-timeout=5 --read-timeout=10 --tries=2 "$l" -O $filename && break
  done
  
}

start_on_boot(){
    local cmd="$1"
    if [[ -f "/etc/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.local
        if [[ `grep "${cmd}" /etc/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.local
        fi 
        chmod +x /etc/rc.local
    fi


    if [[ -f "/etc/rc.d/rc.local" ]]; then
        sed -i '/exit 0/d' /etc/rc.d/rc.local
        if [[ `grep "${cmd}" /etc/rc.d/rc.local` == "" ]];then 
            echo "${cmd}" >> /etc/rc.d/rc.local
        fi 
        chmod +x /etc/rc.d/rc.local 
    fi 
}


#判断系统版本
check_sys(){
    local checkType=$1
    local value=$2

    local release=''
    local systemPackage=''
    local packageSupport=''

    if [[ "$release" == "" ]] || [[ "$systemPackage" == "" ]] || [[ "$packageSupport" == "" ]];then

        if [[ -f /etc/redhat-release ]];then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /etc/issue | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "debian";then
            release="debian"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "ubuntu";then
            release="ubuntu"
            systemPackage="apt"
            packageSupport=true

        elif cat /proc/version | grep -q -E -i "centos|red hat|redhat";then
            release="centos"
            systemPackage="yum"
            packageSupport=true

        else
            release="other"
            systemPackage="other"
            packageSupport=false
        fi
    fi

    echo -e "release=$release\nsystemPackage=$systemPackage\npackageSupport=$packageSupport\n" > /tmp/ezhttp_sys_check_result

    if [[ $checkType == "sysRelease" ]]; then
        if [ "$value" == "$release" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageManager" ]]; then
        if [ "$value" == "$systemPackage" ];then
            return 0
        else
            return 1
        fi

    elif [[ $checkType == "packageSupport" ]]; then
        if $packageSupport;then
            return 0
        else
            return 1
        fi
    fi
}
get_sys_ver() {
cat > /tmp/sys_ver.py <<EOF
import platform
import re

sys_ver = platform.platform()
sys_ver = re.sub(r'.*-with-(.*)-.*',"\g<1>",sys_ver)
if sys_ver.startswith("centos-7"):
    sys_ver = "centos-7"
if sys_ver.startswith("centos-6"):
    sys_ver = "centos-6"
print sys_ver
EOF
echo `python /tmp/sys_ver.py`
}

force_restart() {
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
    sleep 2
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
    sleep 2
    rm -f /var/run/nginx.sock
    ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx
}

upgrade_cmd() {
    SYS_VER=`get_sys_ver`

    # 扫描ocsp，生成hosts
    if check_sys sysRelease ubuntu;then
        apt-get -y install openssl
    elif check_sys sysRelease centos;then
        yum install -y openssl
    fi  

    rm -f /tmp/ocsp_url /tmp/cert_list
    if [[ -d /usr/local/openresty/nginx/conf/vhost/cert/ ]];then
        cd /usr/local/openresty/nginx/conf/vhost/cert/
        echo "get all certs"
        cert_list=`find *.cert -type f`
        if [[ "$cert_list" != "" ]];then
            echo "$cert_list" > /tmp/cert_list

            while read cert;do
                ocsp_url=`openssl x509 -noout -ocsp_uri  -in $cert`
                if [[ $ocsp_url != "" ]];then
                    ocsp_url=`echo "$ocsp_url" | sed -r 's#http://|https://##'`
                    ocsp_url=`echo "$ocsp_url" | sed 's#/.*##'`
                    echo $ocsp_url >> /tmp/ocsp_url
                fi

            done < /tmp/cert_list

            if [[ -f "/tmp/ocsp_url" ]];then 
                cat /tmp/ocsp_url | sort -u | while read url;do
                    if [[ "`grep $url /etc/hosts`" == "" ]];then
                        echo "127.0.0.1 $url" >> /etc/hosts
                    fi
                done
            fi

        fi
    fi

    # 升级openresty
    cd /usr/local
    download "https://raw.githubusercontent.com/sqxiaobai-wq/cdnfly-kaixin/main/cdnfly/openresty-$SYS_VER-20221220.tar.gz" "https://raw.githubusercontent.com/sqxiaobai-wq/cdnfly-kaixin/main/cdnfly/openresty-$SYS_VER-20221220.tar.gz" "openresty-$SYS_VER.tar.gz"

    # 停止nginx
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
    sleep 2
    ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true

    if [[ ! -d "/usr/local/openresty-2023-01-01" ]];then
        mv openresty openresty-2023-01-01
    fi

    tar xf openresty-$SYS_VER.tar.gz || true

    # 恢复配置文件
    chattr -R -i /usr/local/openresty-2023-01-01/ > /dev/null 2>&1 || true
    chattr -R -i /usr/local/openresty/ > /dev/null 2>&1 || true
    \cp -a /usr/local/openresty-2023-01-01/nginx/conf /usr/local/openresty/nginx/

    # 恢复权限
    chattr -R +i /usr/local/openresty/lualib || true
    chattr -R +i /usr/local/openresty/libmaxminddb > /dev/null 2>&1 || true
    chattr -R +i /usr/local/openresty/nginx/sbin/ || true
    chattr -R +i /usr/local/openresty/nginx/modules/ || true

    chattr +i /usr/local/openresty/nginx/conf || true
    chattr +i /usr/local/openresty/nginx/conf/listen_80.conf || true
    chattr +i /usr/local/openresty/nginx/conf/listen_other.conf || true
    chattr +i /usr/local/openresty/nginx/conf/nginx.conf || true

    chattr +i /usr/local/openresty/nginx/conf/stream > /dev/null 2>&1 || true
    chattr +i /usr/local/openresty/nginx/conf/stream/*.conf > /dev/null 2>&1 || true

    chattr +i /usr/local/openresty/nginx/conf/vhost || true
    chattr +i /usr/local/openresty/nginx/conf/vhost/*.conf || true

    # 启动nginx
    rm -f /var/run/nginx.sock && /usr/local/openresty/nginx/sbin/nginx

    # 安装py依赖
    cd /tmp
    download "https://raw.githubusercontent.com/sqxiaobai-wq/cdnfly-kaixin/main/cdnfly/pymodule-agent-20230102.tar.gz" "https://raw.githubusercontent.com/sqxiaobai-wq/cdnfly-kaixin/main/cdnfly/pymodule-agent-20230102.tar.gz" "pymodule-agent-20230102.tar.gz"
    tar xf pymodule-agent-20230102.tar.gz
    cd pymodule-agent-20230102

    /opt/venv/bin/pip install python_engineio-3.11.2-py2.py3-none-any.whl
    /opt/venv/bin/pip install python_socketio-4.4.0-py2.py3-none-any.whl
    /opt/venv/bin/pip install greenlet-2.0.1-cp27-cp27mu-manylinux2010_x86_64.whl
    /opt/venv/bin/pip install gevent-22.10.2-cp27-cp27mu-manylinux2010_x86_64.whl     
    /opt/venv/bin/pip install gevent-websocket-0.10.1.tar.gz
    /opt/venv/bin/pip install websocket_client-0.59.0-py2.py3-none-any.whl 

    # MASTER_HOST = ""
    if [[ "`grep MASTER_HOST /opt/cdnfly/agent/conf/config.py`" == "" ]];then
        # 获取master host
        master_host=""
        if [[ -f "/usr/local/openresty/nginx/conf/listen_80.conf" ]];then
            master_host=`grep "proxy_set_header Host" /usr/local/openresty/nginx/conf/listen_80.conf | awk '{print $NF}' | sed 's/;//g' | sed 's/ //g'`
        elif [[ -f "/usr/local/openresty/nginx/conf/listen_other.conf" ]];then
            master_host=`grep "proxy_set_header Host" /usr/local/openresty/nginx/conf/listen_other.conf | awk '{print $NF}' | sed 's/;//g' | sed 's/ //g'`
        fi

        echo "MASTER_HOST = \"$master_host\" " >> /opt/cdnfly/agent/conf/config.py
    fi

}

update_file() {
cd /opt/$dir_name/
for i in `find ./ | grep -vE "conf/config.py|conf/filebeat.yml|^./agent/conf$|^./$|^./agent$"`;do
    \cp -aT $i /opt/cdnfly/$i
done

}


# 定义版本
version_name="v5.3.0"
version_num="50300"
dir_name="cdnfly-agent-$version_name"
tar_gz_name="$dir_name-$(get_sys_ver).tar.gz"

# 下载安装包
cd /opt
echo "开始下载$tar_gz_name..."
download "https://raw.githubusercontent.com/sqxiaobai-wq/cdnfly-kaixin/main/cdnfly/$tar_gz_name" "https://raw.githubusercontent.com/sqxiaobai-wq/cdnfly-kaixin/main/cdnfly/$tar_gz_name" "$tar_gz_name"
echo "下载完成"

echo "开始解压..."
rm -rf $dir_name
tar xf $tar_gz_name
echo "解压完成"

###########
echo "执行升级命令..."
upgrade_cmd
echo "执行升级命令完成"
###########

echo "更新文件..."
update_file
echo "更新文件完成."

echo "开始重启agent..."

echo "修改config.py版本..."
sed -i "s/VERSION_NAME=.*/VERSION_NAME=\"$version_name\"/" /opt/cdnfly/agent/conf/config.py
sed -i "s/VERSION_NUM=.*/VERSION_NUM=\"$version_num\"/" /opt/cdnfly/agent/conf/config.py
echo "修改完成"

supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf reload || true
sleep 10
supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart all || true

# supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart agent
# supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart task
#supervisorctl -c /opt/cdnfly/agent/conf/supervisord.conf restart filebeat
# ps aux  | grep [/]usr/local/openresty/nginx/sbin/nginx | awk '{print $2}' | xargs kill -HUP || true
# 重启nginx

# ps aux | grep [n]ginx | awk '{print $2}' | xargs kill || true
# sleep 2
# ps aux | grep [n]ginx | awk '{print $2}' | xargs kill -9 || true
# ulimit -n 51200 && /usr/local/openresty/nginx/sbin/nginx

echo "重启完成"


echo "清理文件"
rm -rf /opt/$dir_name
rm -f /opt/$tar_gz_name
echo "清理完成"

echo "完成$version_name版本升级"



